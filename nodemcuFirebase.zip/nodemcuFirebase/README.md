﻿# nodemcuFirebase


Autor: Neiberth Lucena
Data início: 19/12/2019
versão: 0.0.1
Projeto: automação com NodeMCU, Firebase e Ionic 4

*projeto foi criado em cima do blank

Sites referencias: 
    - https://ionicframework.com/docs

Comandos usados:
- IONIC 4
    //comando para criar paginas no projeto
    - ionic generate page pages/home
    - ionic ganerate pape pages/login

Bibliotecas Usadas:
